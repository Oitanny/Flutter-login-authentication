import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import '../../authservice.dart';

class MyLoginPage extends StatefulWidget {
  @override
  LoginForm createState() {
    return LoginForm();
  }
}

class LoginForm extends State<MyLoginPage> {
  final formKey = GlobalKey<FormState>();
  final passwordController = TextEditingController();
  final confirmpasswordController = TextEditingController();
  var name, password, token;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        // The title text which will be shown on the action bar
        title: Text('Registration'),
      ),
      body: Container(
        padding: EdgeInsets.symmetric(
          vertical: 50.0,
          horizontal: 10.0,
        ),
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage("images/signupimg.jpg"),
            fit: BoxFit.cover,
          ),
        ),
        child: Form(
          key: formKey,
          child: Column(
            children: <Widget>[
              Container(
                  margin: EdgeInsets.all(2),
                  padding: const EdgeInsets.all(8.0),
                  child: const Align(
                      alignment: Alignment.topLeft,
                      child: Text(
                        'Login',
                        style: TextStyle(
                          fontSize: 40,
                          fontWeight: FontWeight.bold,
                        ),
                        textAlign: TextAlign.left,
                      ))),
              Container(
                margin: EdgeInsets.all(2),
                padding: const EdgeInsets.all(8.0),
                child: TextFormField(
                  autovalidateMode: AutovalidateMode.onUserInteraction,
                  validator: (String? val) {
                    if (val == null || val.isEmpty) {
                      return 'Username cannot be empty';
                    } else {
                      name = val;
                    }
                    return null;
                  },
                  decoration: InputDecoration(
                      filled: true, //<-- SEE HERE
                      fillColor: Colors.white,
                      labelText: 'Username',
                      hintText: 'Your Username',
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(20.0),
                      )),
                ),
              ),
              Container(
                margin: EdgeInsets.all(2),
                padding: const EdgeInsets.all(8.0),
                child: TextFormField(
                  obscureText: true,
                  controller: passwordController,
                  autovalidateMode: AutovalidateMode.onUserInteraction,
                  validator: (String? val) {
                    if (val == null || val.isEmpty) {
                      return 'Password cannot be empty';
                    } else if (val.length < 6) {
                      return 'Password must be at least 6 characters long.';
                    } else {
                      password = val;
                    }
                    return null;
                  },
                  decoration: InputDecoration(
                      filled: true, //<-- SEE HERE
                      fillColor: Colors.white,
                      labelText: 'Password',
                      hintText: 'Your password',
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(20.0),
                      )),
                ),
              ),
              Container(
                margin: EdgeInsets.all(10),
                padding: EdgeInsets.all(10),
                child: ElevatedButton(
                  child: Text(
                    "Login",
                    style: TextStyle(fontSize: 20),
                  ),
                  onPressed: () {
                    print("Name == $name, Password == $password");
                    AuthService().login(name, password).then((val) {
                      print(val);
                      if (val.data['success'] != null) {
                        token = val.data!['token'];
                        Fluttertoast.showToast(
                          msg: 'Authenticated',
                          toastLength: Toast.LENGTH_SHORT,
                          gravity: ToastGravity.BOTTOM,
                          backgroundColor: Colors.white,
                          textColor: Colors.white,
                          fontSize: 16.0,
                        );
                      }
                    });
                    if (formKey.currentState!.validate()) {
                      debugPrint('All validations passed');
                    }
                    style:
                    ElevatedButton.styleFrom(
                      primary: Colors.orange, // Background color
                      onPrimary: Colors.black, //Text Color (Foreground color)
                      elevation: 3, //elevation of button
                      shape: RoundedRectangleBorder(
                          //to set border radius to button
                          borderRadius: BorderRadius.circular(35)),
                    );
                  },
                ),
              ),
              Container(
                margin: EdgeInsets.all(10),
                child: Text(
                  "Don't have an account?",
                  style: TextStyle(fontSize: 16),
                ),
              ),
              Container(
                  child: TextButton(
                      onPressed: () {
                        Navigator.pushNamed(context, 'register');
                      },
                      child: Text("Sign up",
                          style: TextStyle(
                            decoration: TextDecoration.underline,
                            fontSize: 18,
                            color: Colors.orange,
                          ))))
            ],
          ),
        ),
      ),
    );
  }
}
