import 'package:flutter/material.dart';
import '../../signup.dart';
import '../../login.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  // This widget is the root of our application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      // Application name
      title: 'Registration Form',
      // Application theme data, we can set the colors for the application as
      // you want
      theme: ThemeData(
        primarySwatch: Colors.orange,
      ),
      home: MySignUpPage(),
      routes: {
        'register': (context) => MySignUpPage(),
        'login': (context) => MyLoginPage(),
      },
    );
  }
}
