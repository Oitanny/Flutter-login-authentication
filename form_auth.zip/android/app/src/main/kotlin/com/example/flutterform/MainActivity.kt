package com.example.flutterform

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
